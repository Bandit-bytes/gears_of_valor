/**
 * This class is a fork of the matching class found in the Configuration repository. Original source:
 * https://github.com/Toma1O6/Configuration Copyright © 2024 Toma1O6. Licensed under the MIT License.
 */
package mod.azure.azurelib.config.value;

import java.lang.reflect.Field;

import mod.azure.azurelib.config.ConfigUtils;
import mod.azure.azurelib.config.adapter.TypeAdapter;
import mod.azure.azurelib.config.exception.ConfigValueMissingException;
import mod.azure.azurelib.config.format.IConfigFormat;
import net.minecraft.network.FriendlyByteBuf;

public class FloatValue extends DecimalValue<Float> {

    public FloatValue(ValueData<Float> valueData) {
        super(valueData, Range.unboundedFloat());
    }

    @Override
    public Float getCorrectedValue(Float in) {
        if (this.range == null)
            return in;
        if (!this.range.isWithin(in)) {
            float corrected = this.range.clamp(in);
            ConfigUtils.logCorrectedMessage(this.getId(), in, corrected);
            return corrected;
        }
        return in;
    }

    @Override
    protected void serialize(IConfigFormat format) {
        format.writeFloat(this.getId(), this.get());
    }

    @Override
    protected void deserialize(IConfigFormat format) throws ConfigValueMissingException {
        this.set(format.readFloat(this.getId()));
    }

    public static final class Adapter extends TypeAdapter {

        @Override
        public ConfigValue<?> serialize(
            String name,
            String[] comments,
            Object value,
            TypeSerializer serializer,
            AdapterContext context
        ) throws IllegalAccessException {
            return new FloatValue(ValueData.of(name, (float) value, context, comments));
        }

        @Override
        public void encodeToBuffer(ConfigValue<?> value, FriendlyByteBuf buffer) {
            buffer.writeFloat((Float) value.get());
        }

        @Override
        public Object decodeFromBuffer(ConfigValue<?> value, FriendlyByteBuf buffer) {
            return buffer.readFloat();
        }

        @Override
        public void setFieldValue(Field field, Object instance, Object value) throws IllegalAccessException {
            field.setFloat(instance, (Float) value);
        }
    }
}
