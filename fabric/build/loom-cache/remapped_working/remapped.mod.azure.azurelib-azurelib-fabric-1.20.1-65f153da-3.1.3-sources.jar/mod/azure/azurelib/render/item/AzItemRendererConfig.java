package mod.azure.azurelib.render.item;

import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

import mod.azure.azurelib.animation.AzAnimator;
import mod.azure.azurelib.model.AzBone;
import mod.azure.azurelib.render.*;
import mod.azure.azurelib.render.layer.AzRenderLayer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/**
 * Configuration class for rendering items using customized settings in an animation framework. Extends
 * {@link AzRendererConfig} specifically for handling {@link ItemStack}. Provides additional settings specific to item
 * rendering, such as GUI lighting and custom offsets.
 */
public class AzItemRendererConfig extends AzRendererConfig<UUID, ItemStack> {

    private final boolean useEntityGuiLighting;

    private final boolean useNewOffset;

    private final Predicate<ItemDisplayContext> shouldAnimateInContext;

    private AzItemRendererConfig(
        Supplier<AzAnimator<UUID, ItemStack>> animatorProvider,
        Function<ItemStack, ResourceLocation> modelLocationProvider,
        Function<ItemStack, RenderType> renderTypeProvider,
        List<AzRenderLayer<UUID, ItemStack>> renderLayers,
        Function<AzRendererPipelineContext<UUID, ItemStack>, AzRendererPipelineContext<UUID, ItemStack>> preRenderEntry,
        Function<AzRendererPipelineContext<UUID, ItemStack>, AzRendererPipelineContext<UUID, ItemStack>> renderEntry,
        Function<AzRendererPipelineContext<UUID, ItemStack>, AzRendererPipelineContext<UUID, ItemStack>> postRenderEntry,
        Function<ItemStack, ResourceLocation> textureLocationProvider,
        Function<ItemStack, Float> alphaFunction,
        Function<ItemStack, Float> scaleHeight,
        Function<ItemStack, Float> scaleWidth,
        boolean useEntityGuiLighting,
        boolean useNewOffset,
        Predicate<ItemDisplayContext> shouldAnimateInContext,
        BiFunction<AzRendererPipeline<UUID, ItemStack>, AzLayerRenderer<UUID, ItemStack>, AzModelRenderer<UUID, ItemStack>> modelRendererProvider,
        Function<AzRendererPipeline<UUID, ItemStack>, AzRendererPipelineContext<UUID, ItemStack>> pipelineContextFunction,
        Function<AzBone, ResourceLocation> boneTextureOverrideProvider,
        Function<AzBone, RenderType> boneRenderTypeOverrideProvider
    ) {
        super(
            animatorProvider,
            (a, b) -> modelLocationProvider.apply(b),
            modelRendererProvider,
            pipelineContextFunction,
            (a, b) -> renderTypeProvider.apply(b),
            renderLayers,
            preRenderEntry,
            renderEntry,
            postRenderEntry,
            (a, b) -> textureLocationProvider.apply(b),
            alphaFunction,
            scaleHeight,
            scaleWidth,
            boneTextureOverrideProvider,
            boneRenderTypeOverrideProvider
        );
        this.useEntityGuiLighting = useEntityGuiLighting;
        this.useNewOffset = useNewOffset;
        this.shouldAnimateInContext = shouldAnimateInContext;
    }

    public boolean useEntityGuiLighting() {
        return useEntityGuiLighting;
    }

    public boolean useNewOffset() {
        return useNewOffset;
    }

    public boolean shouldAnimateInContext(ItemDisplayContext context) {
        return shouldAnimateInContext.test(context);
    }

    public static mod.azure.azurelib.render.item.AzItemRendererConfig.Builder builder(
        ResourceLocation modelLocation,
        ResourceLocation textureLocation
    ) {
        return new mod.azure.azurelib.render.item.AzItemRendererConfig.Builder($ -> modelLocation, $ -> textureLocation);
    }

    public static mod.azure.azurelib.render.item.AzItemRendererConfig.Builder builder(
        Function<ItemStack, ResourceLocation> modelLocationProvider,
        Function<ItemStack, ResourceLocation> textureLocationProvider
    ) {
        return new mod.azure.azurelib.render.item.AzItemRendererConfig.Builder(modelLocationProvider, textureLocationProvider);
    }

    public static class Builder extends AzRendererConfig.Builder<UUID, ItemStack> {

        private boolean useEntityGuiLighting;

        private boolean useNewOffset;

        private Predicate<ItemDisplayContext> shouldAnimateInContext;

        protected Builder(
            Function<ItemStack, ResourceLocation> modelLocationProvider,
            Function<ItemStack, ResourceLocation> textureLocationProvider
        ) {
            super((a, b) -> modelLocationProvider.apply(b), (a, b) -> textureLocationProvider.apply(b));
            this.renderTypeProvider = (a, b) -> RenderType.entityCutoutNoCull(textureLocationProvider.apply(b));
            this.useEntityGuiLighting = false;
            this.useNewOffset = false;
            this.shouldAnimateInContext = $ -> true;
            this.modelRendererProvider = (entityRendererPipeline, layer) -> new AzItemModelRenderer(
                (AzItemRendererPipeline) entityRendererPipeline,
                layer
            );
            this.pipelineContextFunction = AzItemRendererPipelineContext::new;
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setBoneRenderTypeOverrideProvider(Function<AzBone, RenderType> boneRenderTypeOverrideProvider) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.setBoneRenderTypeOverrideProvider(boneRenderTypeOverrideProvider);
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setBoneTextureOverrideProvider(Function<AzBone, ResourceLocation> boneTextureOverrideProvider) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.setBoneTextureOverrideProvider(boneTextureOverrideProvider);
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setModelRenderer(
            BiFunction<AzRendererPipeline<UUID, ItemStack>, AzLayerRenderer<UUID, ItemStack>, AzModelRenderer<UUID, ItemStack>> modelRendererProvider
        ) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.setModelRenderer(modelRendererProvider);
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setPipelineContext(
            Function<AzRendererPipeline<UUID, ItemStack>, AzRendererPipelineContext<UUID, ItemStack>> azRendererPipelineAzRendererPipelineContextFunction
        ) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.setPipelineContext(azRendererPipelineAzRendererPipelineContextFunction);
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder addRenderLayer(AzRenderLayer<UUID, ItemStack> renderLayer) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.addRenderLayer(renderLayer);
        }

        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setRenderType(RenderType renderType) {
            this.renderTypeProvider = (a, b) -> renderType;
            return this;
        }

        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setRenderType(Function<ItemStack, RenderType> renderTypeProvider) {
            this.renderTypeProvider = (a, b) -> renderTypeProvider.apply(b);
            return this;
        }

        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setRenderType(BiFunction<Entity, ItemStack, RenderType> renderTypeProvider) {
            this.renderTypeProvider = renderTypeProvider;
            return this;
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setPrerenderEntry(
            Function<AzRendererPipelineContext<UUID, ItemStack>, AzRendererPipelineContext<UUID, ItemStack>> preRenderEntry
        ) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.setPrerenderEntry(preRenderEntry);
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setRenderEntry(
            Function<AzRendererPipelineContext<UUID, ItemStack>, AzRendererPipelineContext<UUID, ItemStack>> renderEntry
        ) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.setRenderEntry(renderEntry);
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setPostRenderEntry(
            Function<AzRendererPipelineContext<UUID, ItemStack>, AzRendererPipelineContext<UUID, ItemStack>> preRenderEntry
        ) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.setPostRenderEntry(preRenderEntry);
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setAnimatorProvider(Supplier<@Nullable AzAnimator<UUID, ItemStack>> animatorProvider) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.setAnimatorProvider(animatorProvider);
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setAlpha(Function<ItemStack, Float> alphaFunction) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.setAlpha(alphaFunction);
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setAlpha(float alpha) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.setAlpha(alpha);
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setScale(Function<ItemStack, Float> scaleFunction) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.setScale(scaleFunction);
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setScale(
            Function<ItemStack, Float> scaleHeightFunction,
            Function<ItemStack, Float> scaleWidthFunction
        ) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.setScale(scaleHeightFunction, scaleWidthFunction);
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setScale(float scale) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.setScale(scale);
        }

        @Override
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setScale(float scaleWidth, float scaleHeight) {
            return (mod.azure.azurelib.render.item.AzItemRendererConfig.Builder) super.setScale(scaleWidth, scaleHeight);
        }

        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder useEntityGuiLighting() {
            this.useEntityGuiLighting = true;
            return this;
        }

        /**
         * @param useNewOffset Determines whether to apply the y offset for a model due to the change in BlockBench
         *                     4.11.
         */
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder useNewOffset(boolean useNewOffset) {
            this.useNewOffset = useNewOffset;
            return this;
        }

        /**
         * Sets the Predicate to determine whether an item should be animated in a specific {@link ItemDisplayContext}.
         *
         * @param shouldAnimateInContext A Predicate that takes an {@link ItemDisplayContext} and returns true if the
         *                               animation should occur in that context; false otherwise.
         * @return The current instance of the {@code Builder} for method chaining.
         */
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder setShouldAnimateInContext(Predicate<ItemDisplayContext> shouldAnimateInContext) {
            this.shouldAnimateInContext = shouldAnimateInContext;
            return this;
        }

        /**
         * Disables animation for specific {@link ItemDisplayContext} instances. The provided contexts are added to a
         * set, and animations will not occur in the specified contexts.
         *
         * @param contextToDisable  The primary {@link ItemDisplayContext} in which animations are to be disabled.
         * @param contextsToDisable Additional {@link ItemDisplayContext} instances in which animations are to be
         *                          disabled.
         * @return The current instance of the {@code Builder} for method chaining.
         */
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder disableAnimationInContexts(
            ItemDisplayContext contextToDisable,
            ItemDisplayContext... contextsToDisable
        ) {
            var disabledContexts = new HashSet<ItemDisplayContext>();
            disabledContexts.add(contextToDisable);

            if (contextsToDisable.length > 0) {
                disabledContexts.addAll(Arrays.asList(contextsToDisable));
            }

            var finalDisabledContexts = Set.copyOf(disabledContexts);
            this.shouldAnimateInContext = context -> !finalDisabledContexts.contains(context);
            return this;
        }

        /**
         * Enables animation only for the specified {@link ItemDisplayContext} instances. Any contexts not provided in
         * the parameters will have animations disabled.
         *
         * @param contextToEnable  The primary {@link ItemDisplayContext} where animations should be enabled.
         * @param contextsToEnable Additional {@link ItemDisplayContext} instances where animations should be enabled.
         * @return The current instance of the {@code Builder} for method chaining.
         */
        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder enableAnimationOnlyInContexts(
            ItemDisplayContext contextToEnable,
            ItemDisplayContext... contextsToEnable
        ) {
            var enabledContexts = new HashSet<ItemDisplayContext>();
            enabledContexts.add(contextToEnable);

            if (contextsToEnable.length > 0) {
                enabledContexts.addAll(Arrays.asList(contextsToEnable));
            }

            var finalEnabledContexts = Set.copyOf(enabledContexts);
            this.shouldAnimateInContext = finalEnabledContexts::contains;
            return this;
        }

        public mod.azure.azurelib.render.item.AzItemRendererConfig.Builder disableAnimationInAllContexts() {
            this.shouldAnimateInContext = context -> false;
            return this;
        }

        @Override
        public AzItemRendererConfig build() {
            var baseConfig = super.build();

            return new AzItemRendererConfig(
                baseConfig::createAnimator,
                baseConfig::modelLocation,
                baseConfig::getRenderType,
                baseConfig.renderLayers(),
                baseConfig::preRenderEntry,
                baseConfig::renderEntry,
                baseConfig::postRenderEntry,
                baseConfig::textureLocation,
                baseConfig::alpha,
                baseConfig::scaleHeight,
                baseConfig::scaleWidth,
                useEntityGuiLighting,
                useNewOffset,
                shouldAnimateInContext,
                baseConfig::modelRendererProvider,
                baseConfig::pipelineContext,
                baseConfig::boneTextureOverrideProvider,
                baseConfig::boneRenderTypeOverrideProvider
            );
        }
    }
}
