package mod.azure.azurelib.platform.services;

import java.util.function.Supplier;
import net.minecraft.core.Registry;

public interface CommonRegistry {

    <T> Supplier<T> register(
        Registry<? super T> registry,
        String registryName,
        Supplier<? extends T> supplier
    );
}
